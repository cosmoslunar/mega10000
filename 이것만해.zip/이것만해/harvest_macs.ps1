Add-Type -AssemblyName System.Runtime.WindowsRuntime

try {
    [Windows.Devices.Bluetooth.Advertisement.BluetoothLEAdvertisementWatcher, Windows.Devices.Bluetooth, ContentType = WindowsRuntime] | Out-Null
    [Windows.Devices.Enumeration.DeviceInformation, Windows.Devices.Enumeration, ContentType = WindowsRuntime] | Out-Null
    [Windows.Devices.Bluetooth.BluetoothDevice, Windows.Devices.Bluetooth, ContentType = WindowsRuntime] | Out-Null

    Write-Host "[SCANNER] Galaxy/Samsung 타겟 스캐너 시작..." -ForegroundColor Green
    Write-Host "[INFO] 30초간 주변 디바이스 스캔 중..." -ForegroundColor Yellow

    $targetDevices = @()
    $allDevices = @()

    $samsungOUIs = @(
        "00:12:FB", "00:15:99", "00:16:32", "00:17:C9", "00:17:D5", "00:18:AF", 
        "00:1A:8A", "00:1B:98", "00:1C:43", "00:1D:25", "00:1E:7D", "00:1F:CC",
        "00:21:19", "00:21:D1", "00:23:39", "00:24:54", "00:26:37", "00:26:CC",
        "00:02:78", "08:00:28", "0C:14:20", "0C:71:5D", "0C:89:10", "10:30:25",
        "10:77:B1", "14:7D:DA", "18:3A:2D", "1C:62:B8", "20:64:32", "24:4B:81",
        "28:39:26", "2C:44:01", "30:07:4D", "34:23:87", "38:AA:3C", "3C:5A:B4",
        "40:4E:36", "44:4E:6D", "48:5A:3F", "4C:66:41", "50:32:37", "54:88:0E",
        "58:23:8C", "5C:0A:5B", "60:6C:66", "64:B8:53", "68:EB:C5", "6C:2F:2C",
        "70:F9:27", "74:45:8A", "78:1F:DB", "7C:61:66", "80:57:19", "84:25:3F",
        "88:32:9B", "8C:77:12", "90:18:7C", "94:35:0A", "98:52:3D", "9C:65:B0",
        "A0:82:1C", "A4:C1:38", "A8:06:00", "AC:36:13", "B0:72:BF", "B4:B6:86",
        "B8:5E:7B", "BC:85:1F", "C0:BD:D1", "C4:12:F5", "C8:BA:94", "CC:07:AB",
        "D0:22:BE", "D4:87:D8", "D8:90:E8", "DC:71:96", "E0:91:F5", "E4:40:E2",
        "E8:50:8B", "EC:1F:72", "F0:25:B7", "F4:0E:11", "F8:04:2E", "FC:A6:21"
    )

    $watcher = [Windows.Devices.Bluetooth.Advertisement.BluetoothLEAdvertisementWatcher]::new()
    $watcher.ScanningMode = [Windows.Devices.Bluetooth.Advertisement.BluetoothLEScanningMode]::Active

    $received = {
        param($sender, $args)
        
        $address = $args.BluetoothAddress
        $mac = '{0:X12}' -f $address
